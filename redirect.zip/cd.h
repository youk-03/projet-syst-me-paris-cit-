#ifndef CD_H
#define CD_H

int cd(int nb_arg, char * arg);

#endif