#ifndef KILL_H
#define KILL_H

int kill_cmd(char *, char *, job_table*); 

#endif
