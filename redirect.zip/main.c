#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <errno.h>
#include <string.h>
#include "mystring.h"
#include "cd.h"
#include "pwd.h"
#include "prompt.h"
#include "job.h"
#include "interrogation_exit.h"
#include "forkexec.h"
#include "kill.h"
#include "redirect.h"
#include "jobs_command.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <unistd.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
    static int last_return = 0;
    static int job_number = 0;


int main (int argc, char *argv[]){

    //signal handling
    reset_signal(1);

    //copy of stdin stdout and stderr
    int stdout_ = dup(1);
    int stdin_ = dup(0);
    int stderr_ = dup(2);
     //faut peut être les fermer non ?
    
    static int redirection[3] = {0,0,0}; //when redirection[i] == 1 it means that dup2 has been used on it 0 : stdin 1 : stdout 2 : stderr

    rl_outstream = stderr;

    using_history();

    pid_t  shell_pgid = getpid();

    int pid = -1;
    char* line_read = NULL; //Readline
    char* prompt= NULL;
    argument *arg = NULL;
    char *path = NULL;
    job_table* job_table = allocate_job_table(5);
    job* job;
    bool isredirect = false;

    if(setpgid(0,0) != 0){ perror("main l.48"); }

    while(1){

    maj_job_table(job_table,false);

    job_number= job_table->length;
    errno = 0;
    path = getcwd(NULL,0); 
    if(path == NULL){
        perror("Main - getcwd :");
        goto error;
    }
    prompt= create_prompt(path,job_number); 
    if(path == NULL){
        goto error;
    }

    


    line_read = readline(prompt);

    if(!line_read){ //ctrl+D
        last_return = exit_jsh(last_return,job_table);
    }

    add_history (line_read);

    arg=split(line_read,' ');

    if (is_process_substitution(arg)){
        argument* tmp = process_substitution(line_read,job_table,last_return, shell_pgid, stdin_, redirection, NULL);
        if (tmp!=NULL){
            free_argument(arg);
            arg=tmp;
        }
    }

    //CASE WHERE REDIRECT TO CHANGE THE FD AND CREATE THE FILE
       if (is_pipe(line_read)){
        free_argument(arg);
        arg = split("pp", ' ');
    }

    else if(get_command(arg) == 5){
        argument* tmp = redirect(arg, redirection);
        if(tmp!=NULL){
            free_argument(arg);
            arg=tmp;       
        }
        else{
            last_return = 1;
        }
        isredirect= true;
    }


    switch(get_command(arg)){
        case 0: last_return = interrogation_point(last_return); break; //?
        case 1: //exit
        if(arg->nbr_arg > 1){
            last_return = exit_jsh(atoi(arg->data[1]),job_table);
         }
        else{
            last_return = exit_jsh(last_return,job_table);
        } 
        break; 
        case 2: last_return = pwd(); break; //pwd
        case 3: 
            if(arg->nbr_arg == 1){ //case where it's only cd
                last_return = cd(0,NULL);
            }
            else if(arg->nbr_arg > 2){ //case where cd is incorrect arg like "cd dd sds z"
                last_return=1;
                char *error= "cd: too many arguments\n";
                if(write(STDERR_FILENO, error, strlen(error)) != strlen(error)){
                    perror("main: write ");
                }
                
            }

            else{//case for cd - or cd my/path
                last_return = cd(1,arg->data[1]);
            }

        break; //cd
        case 4: 

        if(is_background(arg)){

        pid = forkexecBackground(arg->data[0],arg->data); //forkexecBackground
        line_read[strlen(line_read)-2] = '\0';
        job = allocate_job(pid,getpid(),1,line_read,true);

        if(job != NULL) {
            add_job(job,job_table);
            print_jobs(job,2); //.... running ...
        } 
        else goto error;

        }

        else{

        last_return = forkexec(arg->data[0],arg->data,job_table, stdin_, line_read);  //forkexec
        put_jsh_foreground(shell_pgid, stdin_); 

        }

        break;

        case 6: 

        maj_job_table(job_table,true);
        if (arg->nbr_arg > 2) {
            if (strcmp(arg->data[1],"-t")==0){
                last_return = jobs(true,arg->data[2],job_table);
            }
        } else if (arg->nbr_arg > 1) {
            if (strcmp(arg->data[1],"-t")==0){
            last_return = jobs(true,NULL,job_table);
            } else {
              last_return = jobs(false,arg->data[1],job_table);
            }
        }
        else {
            last_return = jobs(false, NULL, job_table);
        }
        break; //jobs   
        case 7: //kill

        if(arg->nbr_arg > 2){
            last_return = kill_cmd(arg->data[1],arg->data[2],job_table);
        }
        else{
            last_return = kill_cmd(arg->data[1],NULL,job_table);
        }

        break;
        case 8: //bg
        if(arg->data[1]){  
        last_return = put_background(get_job(job_table, arg->data[1]));
        }
        else {
            last_return=1;
            dprintf(2,"bg: invalid id\n");
        }
        
        break; 

        case 9: //fg

        if(arg->data[1]){  
        last_return = put_foreground(get_job(job_table, arg->data[1]), -1, job_table, stdin_);
        put_jsh_foreground(shell_pgid, stdin_);
        }
        else{
            last_return = 1;
            dprintf(2,"fg: invalid id\n");
        }
        
        
        break; 

        case 10: // pipeline
   
        job = allocate_job(-1,getpid(),-1,line_read,true);
        if(job!= NULL){
           add_job(job,job_table); 
        }
        else goto error;
   
        last_return = mpipe(line_read,job_table,last_return, shell_pgid, redirection, job); 
        put_jsh_foreground(shell_pgid, stdin_); 
        break;

        default: break;

    }

    if(isredirect){
        
    //putting back every fd to normal
    if(redirection[1] == 1){
    dup2(stdout_,1); 
    redirection[1] = 0;
    }
    if(redirection[0] == 1){
    dup2(stdin_,0); 
    redirection[0] == 0;
    }
    if(redirection[2] == 1){
    dup2(stderr_,2);
    redirection[2] == 0; 
    }
    isredirect=false;
    }

    if(arg != NULL){
      free_argument(arg);
    }
    if(line_read){ 
     free(line_read);
    line_read = NULL;
    }
    if(prompt != NULL){ 
     free(prompt);
    prompt = NULL;
    }
    if(path != NULL){ 
     free(path);
    path = NULL;
    }
}

    close(stderr_);
    close(stdin_);
    close(stdout_);

    return 0;

    error:
    exit_jsh(1,job_table);
    return 1;
}