#ifndef PWD_H
#define PWD_H

int pwd(void); 

#endif